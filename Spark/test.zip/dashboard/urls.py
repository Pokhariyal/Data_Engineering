from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('job-details/<int:pk>/', views.job_details, name="job_details"),
    path('my-applications', views.my_applications, name='my_applications'),
    path('application-delete/<int:pk>/', views.application_delete, name='application_delete'),
]
