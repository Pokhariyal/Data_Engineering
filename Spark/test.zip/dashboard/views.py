from django.contrib import messages
from django.shortcuts import redirect, render
from job.models import ApplyJob, Job
from job.utils import _is_authenticated, _get_page
from django.views.decorators.cache import cache_page

import logging
logger = logging.getLogger(__name__)

# @cache_page(30)
@_is_authenticated
def home(request):
    """
    View function for the home page, displaying a list of jobs based on user-selected filters.
    Decorated with @_is_authenticated to ensure that only authenticated users can access this view.

    Args:
    - request (HttpRequest): The HTTP request object.

    Returns:
    - HttpResponse: Rendered home page with job listings and filter options.
    """
    try:
        query = request.GET.get('title', '')
        location = request.GET.get('location', '')
        job_type = request.GET.get('job_type', '')

        locations = Job.objects.values_list('location', flat=True).distinct()
        job_types = Job.objects.values_list('job_type', flat=True).distinct()

        jobs = Job.objects.filter(
            title__icontains=query.lower(),
            location__icontains=location,
            job_type__icontains=job_type,
            posted=True
        ).order_by('-posted_date')

        jobs = _get_page(request, jobs, 9)

        return render(request, 'home.html', {'jobs': jobs, 'locations': locations, 'job_types': job_types})

    except Exception as e:
        logger.exception("Error in home view: %s", e)
        return render(request, 'error.html')

@_is_authenticated
def job_details(request, pk):
    """
    View function for displaying details of a specific job.
    Decorated with @_is_authenticated to ensure that only authenticated users can access this view.

    Args:
    - request (HttpRequest): The HTTP request object.
    - pk (int): Primary key of the job to be displayed.

    Returns:
    - HttpResponse: Rendered job details page with information about the specified job.
    """
    try:
        job = Job.objects.get(pk=pk, posted=True)
        applied = ApplyJob.objects.filter(user=request.user, job=job).exists()
        context = {'job': job, 'applied': applied}
        return render(request, 'job_details.html', context)
    
    except Job.DoesNotExist:
        logger.exception("Job Does not Exist")
        messages.warning(request, "Job does not exist.")
        return redirect('home')
    
    except Exception as e:
        logger.exception("Error fetching job details: %s", e)
        return render(request, 'error.html')

@_is_authenticated
def my_applications(request):
    """
    View function to display a list of job applications for the logged-in user applicant.
    Decorated with @_is_authenticated to ensure that only authenticated users can access this view.

    Args:
    - request (HttpRequest): The HTTP request object.

    Returns:
    - HttpResponse: Rendered HTML page displaying the user's job applications or an error page in case of exceptions.
    """
    try:
        if request.user.is_applicant:
            jobs = ApplyJob.objects.filter(user=request.user).order_by('-apply_date')
            jobs = _get_page(request, jobs, 10)
            context = {'jobs': jobs}
            return render(request, 'applicant/my_applications.html', context)
        else:
            return redirect('home')
    except Exception as e:
        logger.exception("Error in my_applications view: %s", e)
        print(e)
        return render(request, 'error.html')

@_is_authenticated
def application_delete(request, pk):
    """
    Deletes a job application submitted by the applicant.
    Decorated with @_is_authenticated to ensure that only authenticated users can access this view.

    Args:
        request (HttpRequest): The Django request object.
        pk (int): The primary key of the application to be deleted.

    Returns:
        HttpResponseRedirect: Redirects to the 'my_applications' view on successful deletion,
                            or to 'error.html' if errors occur.
    """
    try:
        if not request.user.is_applicant:
            return redirect('home')
        if not ApplyJob.objects.get(pk=pk):
            return redirect('my_applications')
        applied = ApplyJob.objects.get(pk=pk)
        applied.delete()
        messages.success(request, "Application Deleted")
        return redirect('my_applications')
    
    except Job.DoesNotExist:
        logger.exception("ApplyJob Object Does not Exist")
        messages.warning(request, "Either the Job does not exist or You have not applied to it")
        return redirect('my_applications')
    
    except Exception as e:
        logger.exception("Error fetching job details: %s", e)
        return render(request, 'error.html')
    