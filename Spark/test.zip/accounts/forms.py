from django import forms
from django.core.exceptions import ValidationError
from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from .models import User

import logging
logger = logging.getLogger(__name__)  

class RegisterApplicantForm(UserCreationForm):
    """
    A custom form for registering applicants.
    """

    class Meta:
        """
        Meta information for the form.
        """
        model = User
        fields = ['first_name', 'last_name', 'email', 'password1', 'password2']

    def clean(self):
        """
        Clean and validate form data.

        Raises:
            Exception: Re-raises any exception encountered during cleaning.
        """
        try:
            super().clean()
            first_name = self.cleaned_data.get('first_name')
            if not first_name:
                self._errors['first_name'] = self.error_class(['First Name is required'])
            return self.cleaned_data
        except Exception as e:
            self.add_error(None, str(e))
            logger.error("Error during applicant registration: %s", e)
            raise

    def __str__(self):
        """
        Returns a string representation of the form.
        """
        return str(self.model.first_name)
    
class RegisterRecruiterForm(UserCreationForm):
    """
    A custom form for registering recruiters.
    """

    class Meta:
        """
        Meta information for the form.
        """
        model = User
        fields = ['first_name', 'last_name', 'company', 'email', 'password1', 'password2']

    def clean(self):
        """
        Clean and validate form data.

        Raises:
            Exception: Re-raises any exception encountered during cleaning.
        """
        try:
            super().clean()
            company = self.cleaned_data.get('company')
            first_name = self.cleaned_data.get('first_name')
            if not first_name:
                self._errors['first_name'] = self.error_class(['First Name is required'])
            if not company:
                self._errors['company'] = self.error_class(['Company name is required for Recruiter'])
            return self.cleaned_data
        except Exception as e:
            self.add_error(None, str(e))
            logger.error("Error during recruiter registration: %s", e)
            raise

    def __str__(self):
        """
        Returns a string representation of the form.
        """
        return str(self.model.first_name)

class UpdateRecruiterForm(ModelForm):
    """
    A form for updating recruiter information.
    """
    class Meta:
        """
        Meta information for the form.
        """
        model = User
        fields = ['first_name', 'last_name', 'company']

    def clean(self):
        """
        Clean and validate form data.

        Raises:
            ValidationError: Re-raises any validation error encountered during cleaning.
        """
        try:
            super().clean()
            company = self.cleaned_data.get('company')
            first_name = self.cleaned_data.get('first_name')
            if not first_name:
                self._errors['first_name'] = self.error_class(['First Name is required'])
            if not company:
                self._errors['company'] = self.error_class(['Company name is required for Recruiter'])
            return self.cleaned_data
        except Exception as e:
            self.add_error(None, str(e))
            logger.error("Unexpected error during recruiter update: %s", e)
            raise

    def __str__(self):
        """
        Returns a string representation of the form.
        """
        return str(self.model.first_name)
    
class UpdateApplicantForm(ModelForm):
   """
   A form for updating applicant information.
   """

   class Meta:
       """
       Meta information for the form.
       """
       model = User
       fields = ['first_name', 'last_name']

   def clean(self):
       """
       Clean and validate form data.

       Raises:
           Exception: Re-raises any exception encountered during cleaning.
       """
       try:
           super().clean()
           first_name = self.cleaned_data.get('first_name')
           if not first_name:
               self._errors['first_name'] = self.error_class(['First Name is required'])
           return self.cleaned_data
       except Exception as e:
           self.add_error(None, str(e))
           logger.error("Error during applicant update: %s", e)
           raise

   def __str__(self):
       """
       Returns a string representation of the form.
       """
       return str(self.model.first_name)