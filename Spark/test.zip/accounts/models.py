from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager

class UserManager(BaseUserManager):
    """
    Custom user model manager where email is the unique identifiers
    for authentication instead of usernames.
    """
    def create_user(self, email, password, **extra_fields):
        """
        Create and save a user with the given email and password.
        """
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, email, password, **extra_fields):
        """
        Create and save a SuperUser with the given email and password.
        """
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError(_("Superuser must have is_staff=True."))
        if extra_fields.get("is_superuser") is not True:
            raise ValueError(_("Superuser must have is_superuser=True."))
        return self.create_user(email, password, **extra_fields)

class User(AbstractUser):
    """
    Custom User model extending AbstractUser for authentication purposes.

    Attributes:
    - username (str): User's username, with a maximum length of 10 characters. Can be blank.
    - is_applicant (bool): Indicates whether the user is an applicant. Default is False.
    - is_recruiter (bool): Indicates whether the user is a recruiter. Default is False.
    - company (str): Company name associated with the user. Maximum length is 50 characters. Can be blank.
    - email (str): User's email address, used as the unique identifier for authentication.
                   Maximum length is 70 characters, must be unique, and cannot be blank.
                   Provides custom error messages for uniqueness and blank constraints.
    """
    username = models.CharField(max_length=10, blank=True)
    
    is_applicant = models.BooleanField(default=False)
    is_recruiter = models.BooleanField(default=False)

    company = models.CharField(max_length=50, blank=True)
    
    email = models.EmailField(max_length=70, unique=True, blank = False, error_messages={
                        "unique":"An Account has already been created using same email",
                        "blank":"This field cannot be blank" 
                    })

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    objects = UserManager()
    
    def __str__(self):
        """
        Returns a string representation of the user, displaying the user's email.
        """
        return self.email
    