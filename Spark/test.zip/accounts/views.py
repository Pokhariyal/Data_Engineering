import secrets
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.http import JsonResponse
from django.shortcuts import redirect, render
from job.utils import _is_authenticated
from accounts.models import User
from .forms import (
    RegisterApplicantForm,
    RegisterRecruiterForm,
    UpdateApplicantForm,
    UpdateRecruiterForm,
)

import logging
logger = logging.getLogger(__name__)

def _register_user(request, form_class, role_field):
    """
    Helper function for user registration.

    Args:
        request (HttpRequest): The HTTP request object.
        form_class (class): The form class for user registration
        role_field (str): The field in the user model representing the user's role

    Returns:
        HttpResponse: Renders the registration page or redirects to the home page.
    """
    try:
        if request.user.is_authenticated:
            return redirect('home')
        form = form_class(request.POST or None)
        context = {'form': form, 'role': role_field}
        if request.method == 'POST':
            if form.is_valid():
                user = form.save(commit=False)
                setattr(user, role_field, True)
                user.save()
                messages.success(request, "Your Account has been successfully created")
                return redirect('login')
            else:
                messages.warning(request, "Please enter valid data")
        return render(request, 'register.html', context)
    
    except Exception as e:
        logger.error(f"Error creating user: {e}")
        return render(request, 'error.html')


def register_applicant(request):
    """
    View for registering an applicant user.

    Args:
        request (HttpRequest): The HTTP request object.

    Returns:
        HttpResponse: Renders the registration page or redirects to the home page.
    """
    return _register_user(request, RegisterApplicantForm, 'is_applicant')


def register_recruiter(request):
    """
    View for registering a recruiter user.

    Args:
        request (HttpRequest): The HTTP request object.

    Returns:
        HttpResponse: Renders the registration page or redirects to the home page.
    """
    return _register_user(request, RegisterRecruiterForm, 'is_recruiter')


def login_page(request):
    """
    View for handling user authentication and login.

    Args:
        request (HttpRequest): The HTTP request object.

    Returns:
        HttpResponse: Renders the login page or redirects to the home page.
    """
    try:
        if request.user.is_authenticated:
            return redirect('home')
        if request.method == 'POST':
            email = request.POST.get('email')
            password = request.POST.get('password')
            user = authenticate(request, username=email, password=password)
            if user is not None and user.is_active:
                login(request, user)
                if request.POST.get('remember_me') == 'True':
                    token = secrets.token_urlsafe(32)
                    response = JsonResponse({'token': token})
                    response.set_cookie('remember_me', token, max_age=604800, httponly=True, secure=True)
                else:
                    request.session.set_expiry(0)
                messages.success(request, "Login Successful")
                return redirect('home')
            else:
                messages.warning(request, "Please enter valid details")
        return render(request, 'login.html')
    
    except Exception as e:
        logger.error(f"Error during login: {e}")
        return render(request, 'error.html')

def logout_user(request):
    """
    View for logging out a user.

    Args:
        request (HttpRequest): The HTTP request object.

    Returns:
        HttpResponse: Redirects to the login page.
    """
    try:
        logout(request)
        messages.success(request, "You have been successfully logged out")
        return redirect('login')
    
    except Exception as e:
        logger.error(f"Error logging out: {e}")
        return render(request, 'error.html')
    
@_is_authenticated
def update_profile(request):
    """
    View for updating the user profile.
    Decorated with @_is_authenticated to ensure that only authenticated users can access this view.

    Args:
        request (HttpRequest): The HTTP request object.

    Returns:
        HttpResponse: Renders the update profile page or redirects to the home page.
    """
    try:
        current_user = User.objects.get(id=request.user.id)
        form_class = UpdateApplicantForm if request.user.is_applicant else UpdateRecruiterForm
        form = form_class(request.POST or None, instance=current_user)
        context = {'form': form}
        if request.method == 'POST':
            if form.is_valid():
                form.save()
                login(request, current_user)
                messages.success(request, "Your Profile has been updated!")
                return redirect('home')
            else:
                messages.success(request, "Please Enter Valid data")
        return render(request, 'update_profile.html', context)
    
    except Exception as e:
        logger.error(f"Error Updating User Info: {e}")
        return render(request, 'error.html')
