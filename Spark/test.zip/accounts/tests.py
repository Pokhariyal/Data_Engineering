from django.test import TestCase
from accounts.models import User
from django.urls import reverse

class RegisterUserTest(TestCase):

    def test_successful_applicant_registration(self):
        data = {
            'first_name' : 'test_applicant',
            'email': 'testapplicant@example.com',
            'password1': 'testpassword',
            'password2': 'testpassword',
        }
        
        request = self.client.post('/register-applicant/', data)

        # Assert successful registration and redirection
        self.assertEqual(request.status_code, 302)
        self.assertRedirects(request, '/login/')

        # Check user creation
        user = User.objects.get(email='testapplicant@example.com')
        self.assertTrue(user.is_applicant)

    def test_successful_recruiter_registration(self):
        data = {
            'first_name': 'test_recruiter',
            'email': 'testrecruiter@example.com',
            'password1': 'testpassword',
            'password2': 'testpassword',
            'company': 'Test Company',
        }
        request = self.client.post('/register-recruiter/', data)

        # Assert successful registration and redirection
        self.assertEqual(request.status_code, 302)
        self.assertRedirects(request, '/login/')

        # Check user creation
        user = User.objects.get(email='testrecruiter@example.com')
        self.assertTrue(user.is_recruiter)
        self.assertEqual(user.company, 'Test Company')

    def test_invalid_registration_data(self):
        # Invalid data (missing password)
        data = {
            'email': 'test@example.com',
            'first_name': 'test_user',
        }

        request = self.client.post('/register-applicant/', data)

        # Assert form errors and rendering of registration page
        self.assertEqual(request.status_code, 200)
        self.assertTemplateUsed(request, 'register.html')

        request = self.client.post('/register-recruiter/', data)

        # Assert form errors and rendering of registration page
        self.assertEqual(request.status_code, 200)
        self.assertTemplateUsed(request, 'register.html')

class LoginPageTest(TestCase):

    def test_login_page_renders_for_anonymous_user(self):
        response = self.client.get(reverse('login'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'login.html')

    def test_redirects_authenticated_user_to_home(self):
        user = User.objects.create_user(username='testuser1', password='password123', email="test1@example.com", first_name="adas")
        self.client.force_login(user)
        response = self.client.get(reverse('login'))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, '/')

    def test_successful_login(self):
        user = User.objects.create_user(username='testuser2', password='password123', email="test2@example.com", first_name="adsad")
        data = {'email': user.email, 'password': 'password123'}
        response = self.client.post(reverse('login'), data)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, '/')
        self.assertTrue(response.wsgi_request.user.is_authenticated)

    def test_invalid_login(self):
        data = {'email': 'invalid@email.com', 'password': 'wrongpassword'}
        response = self.client.post(reverse('login'), data)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.wsgi_request.user.is_authenticated)
        self.assertContains(response, 'Please enter valid details')

class LogoutViewTest(TestCase):

    def test_successful_logout(self):
        self.client.login(username='test1@example.com', password='password123')

        response = self.client.get(reverse('logout'))

        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, '/login/')
        self.assertFalse(self.client.session.get('auth_user_id'))

    def test_logout_for_anonymous_user(self):
        response = self.client.get(reverse('logout'))

        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, '/login/')
