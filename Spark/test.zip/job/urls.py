from django.urls import path
from . import views

urlpatterns = [
    path('create-job/', views.create_job, name='create_job'),
    path('update-job/<int:pk>/', views.update_job, name='update_job'),
    path('manage-jobs', views.manage_jobs, name='manage_jobs'),
    path('apply/<int:pk>', views.apply_to_job, name='apply_to_job'),
    path('view-applications/<int:pk>', views.view_applications, name='view_applications'),
    path('update-application-status/<int:pk>', views.update_application_status, name='update_application_status'),
    path('update-posted-status/<int:pk>', views.update_posted_status, name='update_posted_status'),
]
