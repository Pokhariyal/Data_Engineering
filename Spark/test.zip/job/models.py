from django.db import models
from accounts.models import User
from django.conf import settings
from django.core.validators import FileExtensionValidator
from .utils import _upload_to

import logging
logger = logging.getLogger(__name__)

class Job(models.Model):
    """
    Model representing a job listing.

    Attributes:
    - user (ForeignKey): The user associated with the job listing.
    - title (CharField): The title of the job.
    - company (CharField): The company offering the job.
    - location (CharField): The location of the job.
    - job_type (CharField): The type of job
    - description (TextField): A detailed description of the job.
    - posted (BooleanField): Indicates whether the job listing is currently active.
    - posted_date (DateTimeField): The date and time when the job listing was posted.
    """
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=100, blank=False)
    company = models.CharField(max_length=100)
    location = models.CharField(max_length=100, blank=False)
    job_type = models.CharField(max_length=100, choices=[('Full-time', 'Full-time'), ('Part-time', 'Part-time'), ('Contract', 'Contract'), ('Freelance', 'Freelance')], default='Full-time')
    description = models.TextField()
    posted = models.BooleanField(default=True)
    posted_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        """
        Returns a string representation of the job, displaying the job's title.
        """
        return self.title
    
    def save(self, *args, **kwargs):
        """
        Override the save method to perform additional actions before saving.
        """
        try:
            self.title = self.title.lower()
            self.company = self.user.company.lower()
            self.location = self.location.lower()
            super().save(*args, **kwargs)
        except Exception as e:
            logger.exception("Error saving job: %s", e)

class ApplyJob(models.Model):
    """
    Model representing a job application.

    Attributes:
    - JOB_STATUS (list of tuples): Choices for the status of the job application (Accepted, Declined, Pending).
    - user (ForeignKey): The user submitting the job application.
    - job (ForeignKey): The job listing to which the application is submitted.
    - resume (FileField): The resume file uploaded with the job application.
    - status (CharField): The status of the job application (Accepted, Declined, Pending).
    - apply_date (DateTimeField): The date and time when the job application was submitted.
    """
    JOB_STATUS=[('Accepted', 'Accepted'), ('Declined', 'Declined'), ('Pending', 'Pending')]
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    job = models.ForeignKey(Job, on_delete=models.CASCADE)
    resume = models.FileField(
        upload_to=_upload_to,
        validators=[FileExtensionValidator(allowed_extensions=['pdf', 'doc', 'docx'])],
        blank=False
    )
    status = models.CharField(max_length=100, choices=JOB_STATUS, default='Pending')
    apply_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        """
        Returns a string representation of the Applied Job, displaying the user's first name.
        """
        return f"User - {self.user.first_name}, Job - {self.job.title}"
