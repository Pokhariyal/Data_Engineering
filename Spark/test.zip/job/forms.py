from django import forms
from .models import ApplyJob, Job

class JobForm(forms.ModelForm):
    """
    Form for creating a new job listing.
    """
    class Meta:
        """
        Meta information for the form.
        """
        model = Job
        fields = ('title', 'location', 'description', 'job_type')
        exclude = ('user', 'company', 'posted_date')
    
    def __str__(self):
        """
        Returns a string representation of the form.
        """
        return str(self.model.title)
    
class UpdateJobForm(forms.ModelForm):
    """
    Form for updating an existing job listing.
    """
    class Meta:
        """
        Meta information for the form.
        """
        model = Job
        fields = ('title', 'location', 'description', 'job_type')
        exclude = ('user', 'company', 'posted_date')
    
    def __str__(self):
        """
        Returns a string representation of the form.
        """
        return str(self.model.title)

class ApplyJobForm(forms.ModelForm):
    """
    Form for applying to a job listing.
    """
    class Meta:
        """
        Meta information for the form.
        """
        model = ApplyJob
        fields = ['resume']
    
    def __str__(self):
        """
        Returns a string representation of the form.
        """
        return str(self.model.title)
