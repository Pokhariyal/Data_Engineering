from django.contrib import admin
from .models import ApplyJob, Job

admin.site.register(Job)
admin.site.register(ApplyJob)
