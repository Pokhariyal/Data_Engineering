from django.contrib import messages
from .utils import _is_authenticated, _get_page, _is_recruiter
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render, redirect
from job.models import Job, ApplyJob
from .forms import JobForm, UpdateJobForm, ApplyJobForm
from django.views.decorators.cache import cache_page

import logging
logger = logging.getLogger(__name__)

@_is_recruiter
def create_job(request):
    """
    View function for creating a new job listing by a recruiter.
    Decorated with @_is_recruiter to ensure that only authenticated recruiters can access this view.

    Args:
    - request (HttpRequest): The HTTP request object.

    Returns:
    - HttpResponse: Rendered HTML page for creating a new job listing or an error page in case of exceptions.
    """
    try:
        form = JobForm(request.POST or None)
        context = {'form': form}

        if request.method == 'POST':
            if form.is_valid():
                var = form.save(commit=False)
                var.user = request.user
                var.save()
                messages.success(request, "Job has been successfully created")
                return redirect('home')
            else:
                messages.warning(request, "Please enter valid details")
                return render(request, 'recruiter/create_job.html', context)

        return render(request, 'recruiter/create_job.html', context)
    
    except Exception as e:
        logger.error(f"Error creating job: {e}")
        return render(request, 'error.html')


@_is_recruiter
def update_job(request, pk):
    """
    View function for updating a job listing by a recruiter.
    Decorated with @_is_recruiter to ensure that only authenticated recruiters can access this view.

    Args:
    - request (HttpRequest): The HTTP request object.
    - pk (int): The primary key of the job listing to be updated.

    Returns:
    - HttpResponse: Rendered HTML page for updating a job listing or an error page in case of exceptions.
    """
    try:
        job = Job.objects.get(pk=pk, posted=True)
        form = UpdateJobForm(request.POST or None, instance=job)
        context = {'form': form}

        if request.method == 'POST':
            if form.is_valid():
                form.save()
                messages.success(request, "Job has been successfully updated")
                return redirect('home')
            else:
                messages.warning(request, "Please enter valid details")
                return render(request, 'recruiter/update_job.html', context)

        return render(request, 'recruiter/update_job.html', context)
    
    except Job.DoesNotExist:
        logger.exception("Job Does not Exist")
        messages.warning(request, "Job Does not Exist")
        return redirect('manage_jobs')
    
    except Exception as e:
        logger.error(f"Error updating job: {e}")
        return render(request, 'error.html')


@_is_recruiter
def manage_jobs(request):
    """
    View function for managing and displaying job listings posted by a recruiter.
    Decorated with @_is_recruiter to ensure that only authenticated recruiters can access this view.

    Args:
    - request (HttpRequest): The HTTP request object.

    Returns:
    - HttpResponse: Rendered HTML page for managing job listings or an error page in case of exceptions.
    """
    try:
        jobs = _get_page(request, Job.objects.filter(user=request.user).order_by('-posted_date'), 10)
        applications = []
        for job in jobs:
            job.count = ApplyJob.objects.filter(job=job).count()
        context = {'jobs': jobs}
        return render(request, 'recruiter/manage_jobs.html', context)
    
    except Exception as e:
        logger.error(f"Error in loading manage jobs page: {e}")
        return render(request, 'error.html')


@_is_authenticated
def apply_to_job(request, pk):
    """
    View function for allowing applicants to apply to a specific job listing.
    Decorated with @_is_authenticated to ensure that only authenticated users can access this view.

    Parameters:
    - request (HttpRequest): The HTTP request object.
    - pk (int): The primary key of the job listing to which the user is applying.

    Returns:
    - HttpResponse: Rendered HTML page for applying to a job listing or a redirect to 'job_details' in case of specific conditions.
    """
    try:
        if not request.user.is_applicant:
            return redirect('job_details', pk)
        job = Job.objects.get(pk=pk, posted=True)
        applied = ApplyJob.objects.filter(user=request.user, job=job).exists()
        if applied:
            return redirect('job_details', pk)
        if request.method == 'POST':
            form = ApplyJobForm(request.POST, request.FILES)
            if form.is_valid():
                application = form.save(commit=False)
                application.user = request.user
                application.job = job
                application.save()
                messages.success(request, "Applied Successfully")
                return redirect('home')
            else:
                messages.warning(request, "Enter Valid Data")
        else:
            form = ApplyJobForm()
        context = {'form': form}
        return render(request, 'applicant/apply_job.html', context)
    
    except Job.DoesNotExist:
        logger.exception("Job Does not Exist")
        messages.warning(request, "Job Does not Exist")
        return redirect('home')
    
    except Exception as e:
        logger.error(f"Error Applying for Job: {e}")
        return render(request, 'error.html')

@_is_recruiter
def view_applications(request, pk):
    """
    View function for recruiters to view job applications for a specific job listing.
    Decorated with @_is_recruiter to ensure that only authenticated recruiters can access this view.

    Args:
    - request (HttpRequest): The HTTP request object.
    - pk (int): The primary key of the job listing for which applications are to be viewed.

    Returns:
    - HttpResponse: Rendered HTML page for viewing job applications or a redirect to 'home' in case of specific conditions.
    """
    try:
        job = Job.objects.get(pk=pk)
        applications = _get_page(request, ApplyJob.objects.filter(job=job).order_by('-apply_date'), 10)
        context = {'applications': applications}
        return render(request, 'recruiter/view_applications.html', context)
    
    except Job.DoesNotExist:
        logger.exception("Job Does not Exist")
        messages.warning(request, "Job Does not Exist")
        return redirect('home')
    
    except Exception as e:
        logger.error(f"View Applications: {e}")
        return render(request, 'error.html')

@_is_recruiter
def update_application_status(request, pk):
    """
    View function for updating the status of a job application.
    Decorated with @_is_recruiter to ensure that only authenticated recruiters can access this view.

    Args:
    - request (HttpRequest): The HTTP request object.
    - pk (int): The primary key of the job application to update.

    Returns:
    - HttpResponse: Redirect to 'view_applications' for the associated job or a warning message in case of specific conditions.
    """
    try:
        if request.method == 'POST':
            application = ApplyJob.objects.get(pk=pk)
            application.status = request.POST['status']
            application.save()
        return redirect('view_applications', application.job.pk)
    
    except ApplyJob.DoesNotExist:
        logger.exception("Job Does not Exist")
        messages.warning(request, "Application does not Exist")
        return redirect('home')
    
    except Exception as e:
        logger.error(f"Update Application Status: {e}")
        return render(request, 'error.html')

@_is_recruiter
def update_posted_status(request, pk):
    """
    View function for updating the posted status of a job listing.
    Decorated with @_is_recruiter to ensure that only authenticated recruiters can access this view.

    Args:
    - request (HttpRequest): The HTTP request object.
    - pk (int): The primary key of the job listing to update.

    Returns:
    - HttpResponse: Redirect to 'manage_jobs' or a warning message in case of specific conditions.
    """
    try:
        if request.method == 'POST':
            job = Job.objects.get(pk=pk)
            if 'posted' in request.POST:
                job.posted = request.POST['posted'] == 'true'
                job.save()
            else:
                job.posted = False
                job.save()
        return redirect('manage_jobs')
    
    except Job.DoesNotExist:
        logger.exception("Job Does not Exist")
        messages.warning(request, "Job Does not Exist")
        return redirect('home')
    
    except Exception as e:
        logger.error(f"Update Posted Status: {e}")
        return render(request, 'error.html')
