from django.shortcuts import redirect
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

def _is_authenticated(view_func):
    """
    Decorator function to check if a user is authenticated before allowing access to a view.

    Args:
    - view_func (function): The view function to be wrapped.

    Returns:
    - function: The wrapped view function.
    """
    def wrapper(request, *args, **kwargs):
        if request.user.is_authenticated:
            return view_func(request, *args, **kwargs)
        else:
            return redirect('login')

    return wrapper

def _get_page(request, queryset, page_size):
    """
    Helper function to paginate a queryset based on the specified page size.

    Args:
    - request (HttpRequest): The HTTP request object.
    - queryset (QuerySet): The queryset to be paginated.
    - page_size (int): The number of items to display per page.

    Returns:
    - Page: The paginated queryset.
    """
    p = Paginator(queryset, page_size)
    page = request.GET.get('page')
    try:
        jobs = p.get_page(page)
    except PageNotAnInteger:
        jobs = p.page(1)
    except EmptyPage:
        jobs = p.page(p.num_pages)
    return jobs

def _is_recruiter(view_func):
    """
    Decorator function to check if a user is a recruiter before allowing access to a view.

    Args:
    - view_func (function): The view function to be wrapped.

    Returns:
    - function: The wrapped view function.
    """
    def wrapper(request, *args, **kwargs):
        if request.user.is_authenticated:
            if request.user.is_recruiter:
                return view_func(request, *args, **kwargs)
            else:
                return redirect('home')
        else:
            return redirect('login')
 
    return wrapper

def _upload_to(instance, filename):
    """
    Function to determine the upload path for files associated with a job application.

    Args:
    - instance: The instance of the model (ApplyJob) to which the file is attached.
    - filename (str): The original filename of the uploaded file.

    Returns:
    - str: The upload path for the file.
    """
    user = instance.user
    job = instance.job.id
    return f'resume/{str(user)}/{str(job)}/{filename}'